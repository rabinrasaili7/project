


<!-- User Closed.php^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^ -->

<?php include 'database/header.php';?>

<style>
.user_closed_main_colum{
    width: 700px;
    background: white;
    margin-top: 150px;
    margin-bottom: 150px;
    margin-left: auto;
    margin-right: auto;
    border-radius: 5px;
    text-align: center;
    padding-top: 25px;
    padding-bottom: 30px;
    padding-left: 20px;
}



</style>

<div class="user_closed_main_colum">

    <h1> User closed </h1>

    This user is closed :(

    <a href="index.php"> click here to go back -></a>


</div>