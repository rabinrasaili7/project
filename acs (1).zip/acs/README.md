1: downlioad the zip file from https://github.com/MaheshSindhiya/ocean.com.git

2: extract dwonlded file (you will get foldet name 'ocean.com-master')

3: Move/pest that folder to C:\xampp\htdocs

4: Rname the folder to ocean

5: Open chrom and enter http://localhost/phpmyadmin/

	5.1: create now database name 'ocean'
	
	5.2: click on import button at center top position
	
	5.3: Click on 'choose File' Button
	
	5.4: Goto 'C:\xampp\htdocs\ocean\database' and select/doubleClick ocean.sql file
	
	5.5: click on 'Go' Button at bottum right corner
	

6: open chrom/newTab and enter : localhost/ocean

7: Enjoy!!!!! 
