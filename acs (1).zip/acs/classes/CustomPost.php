<?php

class CustomPost {
    private $con;

    public function __construct($con) {
        $this->con = $con;
    }

    // Add your post-related methods here
}

?>
